import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCLfhf_WuAMBzMCjz8yPe6hvdvfszvhafQ",
            authDomain: "landmark-8jr2q6.firebaseapp.com",
            projectId: "landmark-8jr2q6",
            storageBucket: "landmark-8jr2q6.firebasestorage.app",
            messagingSenderId: "1014013009051",
            appId: "1:1014013009051:web:450206cbf5c4c263e6fa3e"));
  } else {
    await Firebase.initializeApp();
  }
}
